#include "Controller.h"

Controller::init(int speed) {
	this->_speed = speed;

	pinMode(EnA, OUTPUT);
	pinMode(EnB, OUTPUT);
	pinMode(EnC, OUTPUT);
	pinMode(EnD, OUTPUT);
  
	pinMode(InA1, OUTPUT);
	pinMode(InA2, OUTPUT);
	pinMode(InA3, OUTPUT);
	pinMode(InA4, OUTPUT);
  
	pinMode(InB1, OUTPUT);
	pinMode(InB2, OUTPUT);
	pinMode(InB3, OUTPUT);
	pinMode(InB4, OUTPUT);
}

Controller::setPositiveY() {
	digitalWrite(InA1, LOW);
	digitalWrite(InA2, HIGH);
	digitalWrite(InA3, HIGH);
	digitalWrite(InA4, LOW);
}

Controller::setNegativeY() {
	digitalWrite(InA1, HIGH);
	digitalWrite(InA2, LOW);
	digitalWrite(InA3, LOW);
	digitalWrite(InA4, HIGH);
}

Controller::setPositiveX() {
	digitalWrite(InB1, LOW);
	digitalWrite(InB2, HIGH);
	digitalWrite(InB3, LOW);
	digitalWrite(InB4, HIGH);
}

Controller::setNegativeY() {
	digitalWrite(InB1, HIGH);
	digitalWrite(InB2, LOW);
	digitalWrite(InB3, HIGH);
	digitalWrite(InB4, LOW);
}

Controller::moveY() {
	analogWrite(EnA, _speed);
	analogWrite(EnB, _speed);
	analogWrite(EnC, 0);
	analogWrite(EnD, 0);
}

Controller::moveX() {
	analogWrite(EnA, 0);
	analogWrite(EnB, 0);
	analogWrite(EnC, _speed);
	analogWrite(EnD, _speed);
}

Controller::moveForward() {
	this->setPositiveY();
	this->moveY();
}

Controller::moveBack() {
	this->setNegativeY();
	this->moveY();
}

Controller::moveLeft() {
	this->setNegativeX();
	this->moveX();
}

Controller::moveRight() {
	this->setPositiveX();
	this->moveX();
}

Controller::stop() {
	digitalWrite(InA1, LOW);
	digitalWrite(InA2, LOW);
	digitalWrite(InA3, LOW);
	digitalWrite(InA4, LOW);
  
	digitalWrite(InB1, LOW);
	digitalWrite(InB2, LOW);
 	digitalWrite(InB3, LOW);
	digitalWrite(InB4, LOW);
}